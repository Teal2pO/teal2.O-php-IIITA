<?php

/**
 * @package    local
 * @subpackage teal
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 * @author     @abhiandthetruth, @thesmallstar
 */

defined('MOODLE_INTERNAL') || die();
$plugin->version  = 2022020501;
$plugin->requires = 2013051400; // Test later
$plugin->release = '1';
$plugin->component = 'local_teal';
