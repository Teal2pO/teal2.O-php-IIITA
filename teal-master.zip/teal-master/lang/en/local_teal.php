<?php

$string['org_global'] = 'Global Organization Username';
$string['github_access_token'] = 'Github Access Token';
